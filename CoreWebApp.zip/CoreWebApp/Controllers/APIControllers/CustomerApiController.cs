﻿using CoreWebApp.Business.Interfaces;
using CoreWebApp.Model.Customer;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Web.Http.Description;

namespace CoreWebApp.Controllers.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerApiController : ControllerBase
    {

        private readonly ICustomerService _customerService;

        public CustomerApiController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        /// <summary>
        /// Saves the vehicle.
        /// </summary>
        /// <param name="vehicle">The vehicle.</param>
        /// <returns></returns>
        [HttpPost]
        [Route("register-customer")]
        public IActionResult RegisterCustomer(CustomerModel customerModel)
        {
            var model = _customerService.RegisterCustomer(customerModel);
            return Ok(model);

        }

        /// <summary>
        /// Get website ids.
        /// </summary>
        /// <param name="webstoreId">The webstore identifier.</param>
        /// <returns>Installation types.</returns>
        [HttpGet]
        [Route("customer-ids")]
        [ResponseType(typeof(List<CustomerId>))]
        public IActionResult GetCustomerIds()
        {
            var model = _customerService.GetCustomerList();
            if (model == null)
                return BadRequest();
            return Ok(model);

        }

    }
}
