﻿using CoreWebApp.Business.Interfaces;
using CoreWebApp.Core.Enums;
using CoreWebApp.Data.EntityModels;
using CoreWebApp.Model.Property;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Description;

namespace CoreWebApp.Controllers.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyApiController : ControllerBase
    {
        /// <summary>
        /// The property service
        /// </summary>
        private readonly IPropertyService _propertyService;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyApiController"/> class.
        /// </summary>
        /// <param name="propertyService">The property service.</param>
        public PropertyApiController(IPropertyService propertyService)
        {
            _propertyService = propertyService;
        }

        /// <summary>
        /// Saves the vehicle.
        /// </summary>
        /// <param name="vehicle">The vehicle.</param>
        [HttpPost]
        [Route("register-property")]
        public IActionResult RegisterProperty(PropertyModel propertyModel)
        {
            var model = _propertyService.RegisterProperty(propertyModel);
            return Ok(model);
        }

        /// <summary>
        /// Get domain by webstore id.
        /// </summary>
        /// <param name="webstoreId">The webstore identifier.</param>
        /// <returns>Webstore domains.</returns>
        [HttpGet]
        [Route("get-propertybycustomerid", Name = nameof(ApiRoute.InsertCustomer))]
        [ResponseType(typeof(List<Property>))]
        public IActionResult GetAvailablePropertyByCustomerId(int CustomerId)
        {
            var model = _propertyService.GetAvailablePropertyByCustomerId(CustomerId);

            if (model == null)
                return BadRequest();
            return Ok(model);
        }

    }
}
