﻿using CoreWebApp.Controllers.APIControllers;
using CoreWebApp.Core.Common;
using CoreWebApp.Core.Enums;
using CoreWebApp.Model.Customer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CoreWebApp.Controllers
{
    public class CustomerController : BaseController
    {
        public IActionResult Index(string m)
        {
            ViewBag.Message = m;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(CustomerViewModel customerModel)
        {
            var baseAddress = new Uri("https://localhost:44337/api/CustomerApi/register-customer");
            var response = await PostServiceAsync(baseAddress.ToString(), GetContent(customerModel));
            var model = await response.Content.ReadAsAsync<ResponseModel>();
            return RedirectToAction("Index", "Customer", new { m = model.Messsage });
        }
    }
}
