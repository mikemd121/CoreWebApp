﻿using CoreWebApp.Core.Common;
using CoreWebApp.Data.BaseOperation;
using CoreWebApp.Data.EntityModels;
using CoreWebApp.Model.Customer;
using CoreWebApp.Model.Property;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CoreWebApp.Controllers.APIControllers
{
    public class PropertyController : BaseController
    {
        /// <summary>
        /// The context
        /// </summary>
        private CoreWebAppDbContext _context;
        public PropertyController(CoreWebAppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string m)
        {
            var baseAddress = new Uri("https://localhost:44337/api/customerapi/customer-ids");
            var model = new PropertyViewModel { customerList = await SetListAsync<CustomerId>(baseAddress.ToString(), "Id", "Name")};
            ViewBag.Message = m;
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProperty(PropertyViewModel propertyModel)
        {
            var baseAddress = new Uri("https://localhost:44337/api/propertyapi/register-property");
            var response = await PostServiceAsync(baseAddress.ToString(), GetContent(propertyModel));
            var model = await response.Content.ReadAsAsync<ResponseModel>();
            return RedirectToAction("Index", "Property", new { m = model.Messsage });  
        }
    }
}
