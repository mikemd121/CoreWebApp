﻿using CoreWebApp.Controllers.APIControllers;
using CoreWebApp.Core.Enums;
using CoreWebApp.Data.BaseOperation;
using CoreWebApp.Data.EntityModels;
using CoreWebApp.Model.Customer;
using CoreWebApp.Model.Property;
using CoreWebApp.Model.SalesViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CoreWebApp.Controllers
{
    public class SalesController : BaseController
    {
        /// <summary>
        /// The context
        /// </summary>
        private CoreWebAppDbContext _context;
        public SalesController(CoreWebAppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var baseAddress = new Uri("https://localhost:44337/api/customerapi/customer-ids");
            var model = new SalesViewModel
            {
                customerList = await SetListAsync<CustomerId>(baseAddress.ToString(), "Id", "Name"),
                propertyList= await SetListAsync<CustomerId>(baseAddress.ToString(), "Id", "Name")
            };
            return View(model);
        }

        public async Task<JsonResult> GetPropertyByCustomerId(int CustomerId)
        {
            var baseAddress = new Uri($"https://localhost:44337/api/propertyapi/get-propertybycustomerid?CustomerId={CustomerId}");        
            var response = await GetServiceAsync(baseAddress.ToString());
            var data = await response.Content.ReadAsAsync<List<Property>>();
            data.Insert(0, new Property { PropertyId = 0, PropertyName = "Select" });
            return Json(new SelectList(data, "PropertyId", "PropertyName"));
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SellProperty(SalesModel salesModel)
        {
            var baseAddress = new Uri("https://localhost:44337/api/salesapi/sell-property");
            var response = await PostServiceAsync(baseAddress.ToString(), GetContent(salesModel));
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index");
            return View();
        }
    }
}
